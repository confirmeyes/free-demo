package com.msb.msbdongbaomanagerweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoManagerWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
