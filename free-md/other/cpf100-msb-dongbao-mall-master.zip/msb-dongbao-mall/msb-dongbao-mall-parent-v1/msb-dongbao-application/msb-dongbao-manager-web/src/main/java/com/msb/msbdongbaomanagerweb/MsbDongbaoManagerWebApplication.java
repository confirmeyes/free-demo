package com.msb.msbdongbaomanagerweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoManagerWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoManagerWebApplication.class, args);
	}

}
