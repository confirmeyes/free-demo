package com.msb.dongbao.portal.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoPortalWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
