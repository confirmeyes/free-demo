package com.msb.dongbao.ums;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoUmsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoUmsApiApplication.class, args);
	}

}
