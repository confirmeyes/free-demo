package com.msb.dongbao.ums;

//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class MsbDongbaoUmsApiApplicationTests {

//	@Test
	void contextLoads() {
	}

}
