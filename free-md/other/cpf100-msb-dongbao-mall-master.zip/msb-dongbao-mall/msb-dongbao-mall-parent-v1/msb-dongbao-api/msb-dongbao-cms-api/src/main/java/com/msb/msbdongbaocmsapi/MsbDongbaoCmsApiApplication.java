package com.msb.msbdongbaocmsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoCmsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoCmsApiApplication.class, args);
	}

}
