package com.msb.msbdongbaocmsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoCmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
