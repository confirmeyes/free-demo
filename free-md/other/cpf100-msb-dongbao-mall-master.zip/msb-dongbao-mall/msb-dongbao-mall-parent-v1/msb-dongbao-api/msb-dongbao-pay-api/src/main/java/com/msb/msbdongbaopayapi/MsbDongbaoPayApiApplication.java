package com.msb.msbdongbaopayapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoPayApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoPayApiApplication.class, args);
	}

}
