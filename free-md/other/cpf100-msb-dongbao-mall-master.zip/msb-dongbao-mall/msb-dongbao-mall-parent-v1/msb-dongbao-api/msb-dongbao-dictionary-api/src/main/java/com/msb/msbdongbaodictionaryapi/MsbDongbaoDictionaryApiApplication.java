package com.msb.msbdongbaodictionaryapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoDictionaryApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoDictionaryApiApplication.class, args);
	}

}
