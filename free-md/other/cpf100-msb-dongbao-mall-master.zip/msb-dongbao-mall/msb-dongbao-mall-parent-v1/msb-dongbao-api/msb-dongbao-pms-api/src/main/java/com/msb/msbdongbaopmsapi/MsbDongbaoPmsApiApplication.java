package com.msb.msbdongbaopmsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoPmsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoPmsApiApplication.class, args);
	}

}
