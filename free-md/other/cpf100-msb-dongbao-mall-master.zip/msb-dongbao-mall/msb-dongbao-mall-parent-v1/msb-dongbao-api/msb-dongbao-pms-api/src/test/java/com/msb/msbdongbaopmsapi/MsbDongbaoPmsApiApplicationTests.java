package com.msb.msbdongbaopmsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoPmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
