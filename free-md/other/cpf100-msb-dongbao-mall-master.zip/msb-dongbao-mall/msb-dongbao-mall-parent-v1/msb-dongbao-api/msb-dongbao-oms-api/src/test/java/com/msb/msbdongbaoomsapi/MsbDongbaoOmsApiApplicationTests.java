package com.msb.msbdongbaoomsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoOmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
