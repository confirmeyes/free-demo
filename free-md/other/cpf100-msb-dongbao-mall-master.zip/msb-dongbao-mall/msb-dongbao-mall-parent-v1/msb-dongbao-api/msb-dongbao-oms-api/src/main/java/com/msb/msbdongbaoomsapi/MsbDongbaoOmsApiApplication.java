package com.msb.msbdongbaoomsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoOmsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoOmsApiApplication.class, args);
	}

}
