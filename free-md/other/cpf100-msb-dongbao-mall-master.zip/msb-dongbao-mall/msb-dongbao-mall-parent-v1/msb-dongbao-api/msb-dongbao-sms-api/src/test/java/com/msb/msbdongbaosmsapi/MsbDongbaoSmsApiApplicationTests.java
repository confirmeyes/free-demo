package com.msb.msbdongbaosmsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoSmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
