package com.msb.msbdongbaocommonutil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoCommonUtilApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoCommonUtilApplication.class, args);
	}

}
