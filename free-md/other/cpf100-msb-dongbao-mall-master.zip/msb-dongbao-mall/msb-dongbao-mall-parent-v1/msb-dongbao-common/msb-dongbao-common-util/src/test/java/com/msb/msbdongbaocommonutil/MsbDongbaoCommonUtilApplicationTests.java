package com.msb.msbdongbaocommonutil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoCommonUtilApplicationTests {

	@Test
	void contextLoads() {
	}

}
