package com.msb.dongbao.common.base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoCommonBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoCommonBaseApplication.class, args);
	}

}
