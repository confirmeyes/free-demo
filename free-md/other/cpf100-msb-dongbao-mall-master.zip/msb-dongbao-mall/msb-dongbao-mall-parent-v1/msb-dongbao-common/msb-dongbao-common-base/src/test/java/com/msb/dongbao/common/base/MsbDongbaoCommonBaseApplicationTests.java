package com.msb.dongbao.common.base;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoCommonBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
