package com.msb.dongbao.common.base;

/**
 * @author 马士兵教育:chaopengfei
 * @date 2021/1/27
 */
public class TokenException extends Exception {
	public TokenException(String message) {
		super(message);
	}
}
