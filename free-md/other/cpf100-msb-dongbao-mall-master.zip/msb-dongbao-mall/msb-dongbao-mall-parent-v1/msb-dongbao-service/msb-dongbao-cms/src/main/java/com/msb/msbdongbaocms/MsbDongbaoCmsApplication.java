package com.msb.msbdongbaocms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoCmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoCmsApplication.class, args);
	}

}
