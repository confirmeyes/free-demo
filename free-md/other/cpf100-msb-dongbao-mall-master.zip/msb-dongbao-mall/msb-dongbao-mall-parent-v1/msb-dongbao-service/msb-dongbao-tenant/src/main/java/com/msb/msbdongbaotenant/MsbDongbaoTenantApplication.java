package com.msb.msbdongbaotenant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoTenantApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoTenantApplication.class, args);
	}

}
