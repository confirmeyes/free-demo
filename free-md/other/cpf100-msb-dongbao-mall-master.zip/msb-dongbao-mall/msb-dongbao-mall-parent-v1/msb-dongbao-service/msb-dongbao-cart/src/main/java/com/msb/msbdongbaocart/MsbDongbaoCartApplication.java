package com.msb.msbdongbaocart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoCartApplication.class, args);
	}

}
