package com.msb.msbdongbaocart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
