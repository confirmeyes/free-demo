package com.msb.msbdongbaopms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoPmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
