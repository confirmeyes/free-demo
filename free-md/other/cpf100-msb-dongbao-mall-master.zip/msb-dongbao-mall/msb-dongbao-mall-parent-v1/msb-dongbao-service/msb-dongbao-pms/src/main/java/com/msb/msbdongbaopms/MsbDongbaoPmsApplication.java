package com.msb.msbdongbaopms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoPmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoPmsApplication.class, args);
	}

}
