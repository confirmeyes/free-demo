package com.msb.msbdongbaopay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoPayApplicationTests {

	@Test
	void contextLoads() {
	}

}
