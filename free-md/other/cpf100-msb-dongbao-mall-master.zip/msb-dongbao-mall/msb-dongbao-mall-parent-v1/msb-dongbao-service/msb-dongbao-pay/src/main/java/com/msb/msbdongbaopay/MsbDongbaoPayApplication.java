package com.msb.msbdongbaopay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoPayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoPayApplication.class, args);
	}

}
