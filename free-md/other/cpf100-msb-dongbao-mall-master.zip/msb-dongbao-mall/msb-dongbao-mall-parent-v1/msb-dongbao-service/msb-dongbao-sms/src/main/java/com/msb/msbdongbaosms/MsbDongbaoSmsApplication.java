package com.msb.msbdongbaosms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbDongbaoSmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsbDongbaoSmsApplication.class, args);
	}

}
