package com.msb.msbdongbaosms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoSmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
