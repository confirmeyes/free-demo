package com.msb.msbdongbaooms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoOmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
