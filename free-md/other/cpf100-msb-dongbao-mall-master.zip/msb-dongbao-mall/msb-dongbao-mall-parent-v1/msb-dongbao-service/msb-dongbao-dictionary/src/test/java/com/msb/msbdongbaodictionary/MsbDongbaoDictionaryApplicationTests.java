package com.msb.msbdongbaodictionary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoDictionaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
