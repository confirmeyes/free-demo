package com.msb.dongbao.ums;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbDongbaoUmsApplicationTests {

	@Test
	void contextLoads() {
	}



}
