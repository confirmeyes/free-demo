package com.msb.dongbao.ums.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 后台用户表 前端控制器
 * </p>
 *
 * @author 晁鹏飞
 * @since 2020-12-23
 */
@RestController
@RequestMapping("/ums-member")
public class UmsMemberController {


}

